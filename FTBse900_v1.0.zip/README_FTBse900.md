## Corpus FTBse900

https://frenchreflverbs.github.io/French-Reflexive-Verbs/

**version 1.0**, 15 avril 2019

**Authors**: Lucie Barque, Marie Candito et Richard Huyghe

### Content

900 instances of verbs bearing a reflexive clitic "se", extracted from the French Treebank (http://ftb.linguist.univ-paris-diderot.fr/),
annotated into 13 categories (other 3 categories were not found in these 900 instances).

### Annotation guide

See main site : https://frenchreflverbs.github.io/French-Reflexive-Verbs/

### Reference

If you want more information or use the corpus, please refer to:

Barque Lucie, Candito Marie and Huyghe Richard. Classification des verbes pronominaux à l'épreuve d'une annotation en corpus, à paraître dans *Langage*, "Les formes réfléchies du verbe: aspects théoriques et approches empiriques".

