## Corpus FTBse900

https://frenchreflverbs.github.io/French-Reflexive-Verbs/

**version 1.0**, 15 avril 2019

**Authors**: Lucie Barque, Marie Candito et Richard Huyghe

### Content

900 instances of verbs bearing a reflexive clitic "se", extracted from the French Treebank (http://ftb.linguist.univ-paris-diderot.fr/),
annotated into 13 categories (other 3 categories were not found in these 900 instances).

Each line contains one annotated instance, in tab-separated format.
Columns:
- lemma of the verb
- id of the sentence in the French Treebank
- rank of the reflexive clitic token in the sentence
- type of the conflict before adjudication:
  -- ACCORD = no conflict
  -- ERREUR = error while applying the decision tree, by one of the annotators
  -- DESACC_TEST = persisting disagreement concerning the results of some tests
  -- METHOTO = lack of precision in the annotation guide
- adjudicated category

The three last columns contain the tokenized sentence:
- left context of the reflexive clitic
- form of the reflexive clitic
- right context


### Annotation guide

See main site : https://frenchreflverbs.github.io/French-Reflexive-Verbs/

### Reference

If you want more information or use the corpus, please refer to:

Barque Lucie, Candito Marie and Huyghe Richard. Classification des verbes pronominaux à l'épreuve d'une annotation en corpus, à paraître dans *Langage*, "Les formes réfléchies du verbe: aspects théoriques et approches empiriques".

